String.prototype.trim = function () {
    return this.replace(/^\s+|\s+$/g, "");
}

String.prototype.isInteger = function () {
    return (this.search(/^-?[0-9]+$/) == 0)
}

function GetWindowWidth() {
    var theWidth = 800;

    if (window.innerWidth)
        theWidth = window.innerWidth;
    else if (document.documentElement && document.documentElement.clientWidth)
        theWidth = document.documentElement.clientWidth;
    else if (document.body)
        theWidth = document.body.clientWidth;

    return theWidth;
}

function GetWindowHeight() {
    var theHeight = 600;

    if (window.innerHeight)
        theHeight = window.innerHeight;
    else if (document.documentElement && document.documentElement.clientHeight)
        theHeight = document.documentElement.clientHeight;
    else if (document.body)
        theHeight = document.body.clientHeight;

    return theHeight;
}

function ShowOverlay() {
    // if ((navigator.userAgent.toLowerCase().indexOf('chrome') > -1)) {
    $('.showoverlay').remove();
    var winWidth = GetWindowWidth();
    var winHeight = GetWindowHeight();
    scroll(0, 0);
    $('body').append("<div style=\"position:absolute; top:0px; left:0px; width:" + winWidth + "px; height:" + winHeight + "px; overflow:hidden; filter:alpha(opacity=40); -moz-opacity: 0.5; opacity:0.5; z-index:5;\" class=\"showoverlay modalBackground\"></div>").css('overflow', 'hidden');
    //  }
}

function HideOverlay() {
    $('.showoverlay').remove();
    $('body').css('overflow', '');
}

function ZoomOut() {
    zoomLevel = 1;
    zoomLevel -= (0.05);
    if ((navigator.userAgent.toLowerCase().indexOf('chrome') > -1)) {
        $('body').css({ zoom: zoomLevel, '-moz-transform': 'scale(' + zoomLevel + ')' });
    }
}

function ZoomIn() {
    zoomLevel = 1;
    zoomLevel += (0.05);
    if (!(navigator.userAgent.toLowerCase().indexOf('chrome') > -1)) {
        $('body').css({ zoom: zoomLevel, '-moz-transform': 'scale(' + zoomLevel + ')' });
    }
}


function ValidatPageOnSave(showDetail) {
    var flag = true;
    $('.messageBody').removeClass('error').removeClass('accept').addClass('error').hide();

    $('span').removeClass('error');

    var flag = Page_ClientValidate(showDetail);

    if (!flag) {
        MakeLablesRed(showDetail);
    }

    if (!flag) {
        $('.messageBody').removeClass('error').removeClass('accept').addClass('error').show();
        $('.messageBody >  div').show();
        scroll(0, 0);
    }
    else {
        $('.messageBody').removeClass('error').removeClass('accept').hide();
    }
}

//this method is used to red the labels on all pages.
//set labels color red if validation false on any fields.
function MakeLablesRed(groupName) {
    var errMessage = '';
    var flagRq = false;
    var flagRg = false;
    var validationGroupName = '';
    if (Page_Validators != undefined && Page_Validators != null) {
        for (var i = 0; i < Page_Validators.length; i++) {
            if (!Page_Validators[i].isvalid) {
                if (validationGroupName === '') {
                    if (Page_Validators[i].validationGroup != undefined) {
                        validationGroupName = Page_Validators[i].validationGroup;
                    }
                }
                var idPrefix = Page_Validators[i].id.split('_');
                if (idPrefix.length > 1) {
                    $('#' + idPrefix[0] + '_' + $(Page_Validators[i]).attr('ele')).addClass('error');
                    if (idPrefix[1].search(/rq/g) != -1) {
                        if (!flagRq) {
                            flagRq = true;
                            if (!flagRg) {
                                if (validationGroupName === groupName) {
                                    errMessage = '<ul><li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                            else {
                                if (validationGroupName === groupName) {
                                    errMessage += '<li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                        }
                    }
                    else {
                        if (!flagRg) {
                            flagRg = true;
                            if (!flagRq) {
                                if (validationGroupName === groupName) {
                                    errMessage = '<ul><li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                            else {
                                if (validationGroupName === groupName) {
                                    errMessage += '<li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                        }
                    }
                }
                else {
                    $('#' + $(Page_Validators[i]).attr('ele')).addClass('error');
                    if (idPrefix[0].search(/rq/g) != -1) {
                        if (!flagRq) {
                            flagRq = true;
                            if (!flagRg) {
                                if (validationGroupName === groupName) {
                                    errMessage = '<ul><li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                            else {
                                if (validationGroupName === groupName) {
                                    errMessage += '<li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                        }

                    }
                    else {
                        if (!flagRg) {
                            flagRg = true;
                            if (!flagRq) {
                                if (validationGroupName === groupName) {
                                    errMessage = '<ul><li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                            else {
                                if (validationGroupName === groupName) {
                                    errMessage += '<li>' + Page_Validators[i].errormessage + '</li>';
                                }
                            }
                        }
                    }
                }
            }
        }
        if (flagRg || flagRq) {

            $('.messageBody > div').html(errMessage + '</ul>').show();

        }

    }
}

//This method is added by Anand
//This is used to scroll up the page

function ScrollUp() {
   
        var error = $('.messageBody > div > ul > li').size();
        if (error > 0) {
      
            scroll(0, 0);
            return false;
        }
   
}

//This method is added by Anand
//This is used to heighlight top menu.
function MakeTopMenuHeighlight() {
    var path = document.location.href;
    $(".ddsmoothmenu > ul > li > a").removeClass("selected").attr("rel", ""); ;
    if (path.toLowerCase().search(/AddProfile.aspx/i) != -1
        || path.toLowerCase().search(/AddUser.aspx/i) != -1
        || path.toLowerCase().search(/ProfileSearch.aspx/i) != -1
        || path.toLowerCase().search(/SearchUser.aspx/i) != -1) {
        $(".ddsmoothmenu > ul > li > a > span").each(function () {
            if ($(this).html() === "User Access Management") {
                $(this).parent().addClass("selected").attr("rel","yes");
            }
        });
    }
    else if (path.toLowerCase().search(/managedevice.aspx/i) != -1
        || path.toLowerCase().search(/forcematch.aspx/i) != -1
        || path.toLowerCase().search(/undomatch.aspx/i) != -1
        || path.toLowerCase().search(/deleteregistration.aspx/i) != -1
        || path.toLowerCase().search(/businessrulesdeviceinfo.aspx/i) != -1
        || path.toLowerCase().search(/customerdeviceinfo.aspx/i) != -1
        || path.toLowerCase().search(/faultdeviceinfo.aspx/i) != -1
        || path.toLowerCase().search(/hfsideviceinfo.aspx/i) != -1
        || path.toLowerCase().search(/meterdeviceinfo.aspx/i) != -1
        || path.toLowerCase().search(/servicehistorydeviceinfo.aspx/i) != -1
        || path.toLowerCase().search(/suppliesdeviceinfo.aspx/i) != -1
        || path.toLowerCase().search(/generaldeviceinfo.aspx/i) != -1
        ) {
        $(".ddsmoothmenu > ul > li > a > span").each(function () {
            if ($(this).html() === "Device Management") {
                $(this).parent().addClass("selected").attr("rel", "yes");
            }
        });
    }
    else if (path.toLowerCase().search(/AddParameters.aspx/i) != -1
        || path.toLowerCase().search(/SearchParameters.aspx/i) != -1
        ) {
        $(".ddsmoothmenu > ul > li > a > span").each(function () {
            if ($(this).html() === "Parameter Maintenance") {
                $(this).parent().addClass("selected").attr("rel", "yes");
            }
        });
    }
    else if (path.toLowerCase().search(/ManageAlert.aspx/i) != -1
        ) {
        $(".ddsmoothmenu > ul > li > a > span").each(function () {
            if ($(this).html() === "Alert Queue") {
                $(this).parent().addClass("selected").attr("rel", "yes");
            }
        });
    }
    else if (path.toLowerCase().search(/AddBusinessRule.aspx/i) != -1
        || path.toLowerCase().search(/AlertActionMatrix.aspx/i) != -1
        || path.toLowerCase().search(/BusinessRule.aspx/i) != -1
        || path.toLowerCase().search(/ConfigureActionTemplate.aspx/i) != -1
        || path.toLowerCase().search(/TemplateDetails.aspx/i) != -1
        ) {
        $(".ddsmoothmenu > ul > li > a > span").each(function () {
            if ($(this).html() === "Alert Management") {
                $(this).parent().addClass("selected").attr("rel", "yes");
            }
        });
    }
}

var timeOutEvent = '';

function SessionTimeOut(sessionTimeout) {
    if(timeOutEvent != undefined && timeOutEvent != '')
    {
        clearTimeout(timeOutEvent);
    }
    var hdnSetTimeoutID = $("input[id*='hdnSetTimeoutID']");
    if (hdnSetTimeoutID != undefined && hdnSetTimeoutID != null) {
        if (hdnSetTimeoutID.val() != undefined && hdnSetTimeoutID.val() != '') {
            clearTimeout(hdnSetTimeoutID.val());
        } 
    }
    var sessionTimeoutWarning = parseInt(sessionTimeout) - 2;
    var sTimeout = parseInt(sessionTimeoutWarning) * 60 * 1000;
    timeOutEvent = setTimeout(function () { SessionWarning(); }, sTimeout);
    if (hdnSetTimeoutID != undefined && hdnSetTimeoutID != null) {
        hdnSetTimeoutID.val(timeOutEvent);
    }
}

function SessionWarning() {
    //#534
    if (window.location.href.indexOf('CustomerDeviceInfo.aspx') > 0) {
        $.ajax({
            type: "POST",
            url: "/CommonSvc.asmx/RemoveData",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                window.location = '/Login.aspx';
            },
            failure: function (response) {
                alert('Error!');
            }
        });

    }
    else {
        var message = "Your session is inactive.  If no operation is performed in the next two minutes, you will be redirected to your Default Page.  Please save your work before this session expires.";
        alert(message);
    }
}


