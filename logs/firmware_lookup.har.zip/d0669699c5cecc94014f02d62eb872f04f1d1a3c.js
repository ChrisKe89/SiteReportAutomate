ddsmoothmenu.init({
	 mainmenuid: "smoothmenu1", //menu DIV id
	 orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	 classname: 'ddsmoothmenu', //class added to menu's outer DIV
	 //customtheme: ["#1c5a80", "#18374a"],
	 contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})


//$(document).ready(function () {

//    $('.searchGrid table tr:nth-child(odd)').addClass('odd');
//    $('.searchGrid table tr:nth-child(even)').addClass('even');
//    $(".searchGrid table tr th:last-child").css("border-right", "none");
//    $(".searchGrid table tr td:last-child").css("border-right", "none");




//    $('.deleteRow').css('cursor', 'pointer');
//    $('.UdeleteRow').css('cursor', 'pointer');
//    $('.BdeleteRow').css('cursor', 'pointer');


//    $(".calUsage").click(function () {
//        $("#showCal").slideToggle("slow");
//    });


//    $('.searchBusinessDef').click(function () {
//        $('.searchGrid').slideDown("slow");
//        return false;
//    });

//    $('.searchManageUser').click(function () {
//        $('.searchGrid').slideDown("slow");
//        return false;
//    });

//    $('.searchMaintainPara').click(function () {
//        $('.searchGrid').slideDown("slow");
//        return false;
//    });

//    $('.searchManageProfile').click(function () {
//        $('.searchGrid').slideDown("slow");
//        return false;
//    });

//    $('.searchActionConfig').click(function () {
//        $('.searchGrid').slideDown("slow");
//        return false;
//    });


//    $(".showgrid").click(function () {
//        $("#regConGrid").slideDown("slow");
//        return false;
//    });

//    $(".showgrid-deleteTab").click(function () {
//        $("#regConGrid-deleteTab").slideDown("slow");
//        return false;
//    });

//    $(".showgrid-act-deleteTab").click(function () {
//        $("#listActivationGrid-deleteTab").slideToggle("slow");
//        return false;
//    });

//    $(".listActivation").click(function () {
//        $("#listActivationGrid").slideToggle("slow");
//        return false;
//    });


//    $(".listDevMap").click(function () {
//        $("#listDeviceGrid").slideToggle("slow");
//        return false;
//    });

//    $(".undoMathGrid").click(function () {
//        $("#listDeviceGridUndo").slideDown("slow");
//        return false;
//    });


//    $('.forceMatch').click(function () {
//        confirm("Do you want to Match the selected records?");
//    });

//    $('.delinkRecord').click(function () {
//        var val = confirm("Do you want to undo the matching of the selected record?");
//        if (val) {
//            confirm("The registration and activation records will be available for matching after one day");
//        }
//    });

//    $('.deleteRow').click(function () {
//        confirm('Do you want to delete this registration record?');
//    });
//    $('.deleteRowactive').click(function () {
//        confirm('Do you want to delete this activation record?');
//    });

//    $('.UdeleteRow').live('click', function () {
//        confirm(' Do you want to remove this profile from the user?');
//    });

//    $('.BdeleteRow').click(function () {
//        confirm('Do you want to delete this Business Rule?');
//    });


//    $('.appAction').click(function () {
//        confirm('Do you want to Apply Action on this record?');
//    });

//    $('.Collapsible').toggle(
//			function () {
//			    $('.CollapsiblePanel').slideUp("slow");
//			    $('.Collapsible').addClass('Collapsible-plus');
//			    return false;
//			},
//			function () {
//			    $('.CollapsiblePanel').slideDown("slow");
//			    $('.Collapsible').removeClass('Collapsible-plus');
//			    return false;
//			}
//		);


//    $('.showManageD').click(function () {

//        //var val = confirm('The search result exceeds 200 records and may take some time to process.\nClick OK to continue with the search or Cancel to change the search criteria.');
//        //if(val){
//        $('.manageDresult').slideDown("slow");
//        return false;
//        //}
//    });


//    $('.showManageAlert').click(function () {
//        //var val = confirm('The result of the given search criteria exceeds the limit of 200 records and would take time.\nClick OK to continue or Cancel to change search criteria');
//        //if(val){
//        $('.manageAresult').slideDown("slow");
//        return false;
//        //}
//    });



//    $('.searchGrid table tr td, table.roles tr td ').click(function () {        
//        $('.searchGrid table tr, table.roles tr').removeClass('active');
//        $(this).parent().addClass('active');
//    });

//    $('ul.menu li a').click(function () {
//        $('ul.menu li').removeClass('active');
//        $(this).parent().addClass('active');
//    });


//    $('.searchGrid table tr td').click(function () {
//        $('.searchGrid table tr').removeClass('active');
//        $(this).parent().addClass('active');
//    });

//    $('.listing th a').click(function () {
//        $('.listing th a').removeClass('active');
//        $(this).addClass('active');
//    });


//    $('#selectColumns input[type=checkbox]').click(function () {
//        if ($(this).is(':checked') == true) {
//            var rel = "." + $(this).parent().attr('rel');
//            $(rel).removeClass('hideColumn');
//        } else {
//            var rel = "." + $(this).parent().attr('rel');
//            $(rel).addClass('hideColumn');
//        }
//    });


//    $('.showHide_1').click(function () {
//        var targetDiv = '#' + $(this).attr('name');
//        if (!$(targetDiv).hasClass('open')) {
//            $('.showHideBox_1').hide().removeClass('open');
//            $(targetDiv).slideDown().addClass('open');
//        }
//    });


//    $('.showHideBox_1 a.closeBTN, .showHideBox_1 input.cancel').click(function () {
//        $('.showHideBox_1').hide();
//        $('.showHideBox_1').removeClass('open');
//    });

//    if ($('#selectColumns').length) {
//        $("#selectColumns li label").draggable({ helper: 'clone' });
//    }

//    if ($('.listing1 th').length > 0) {
//        $(".listing1 th").droppable({
//            drop: function (event, ui) {
//                var dropElem = $(this);
//                onDrop(event, ui, dropElem);
//            },
//            accept: "#selectColumns li label"
//        });
//    }



//});

//	
//	
//	   function onDrop(ev, ui, dropElem){
//		var elemPos = dropElem.attr('class').split(" ");
//		var elemPosClass = '.'+ elemPos[0];
//		var elemClass = ui.draggable.parent().attr('rel');
//		var elemsPos = [];
//		var elems = [];
//		$(elemPosClass).each(function(){
//			elemsPos.push($(this));
//		});
//		$('.'+elemClass).each(function(){
//			elems.push($(this).html());
//		});
//		if(elemPos[0] != elemClass){
//			$('.'+elemClass).remove();
//			ui.draggable.prev().attr('checked','true');
//			for(var i =0; i<elems.length; i++ ){
//				if(i==0){
//					var htmlContent = '<th class="'+elemClass+' ui-droppable">'+elems[i]+'</th>';
//					elemsPos[i].before(htmlContent);
//				}else{
//					var htmlContent = '<td class="'+elemClass+'">'+elems[i]+'</td>';
//					elemsPos[i].before(htmlContent);
//				}
//			}
//		}
//	}



//$(document).ready(function(){
//	if($('#selectColumns').length){					   
//		$("#selectColumns li label").draggable({helper: 'clone'});
//	}
//	if($('.listing1 th').length > 0){
//		$(".listing1 th").droppable({
//			drop: function(event, ui){
//				var dropElem = $(this);
//				onDrop(event, ui, dropElem);
//			},
//			accept: "#selectColumns li label"
//		});
//	}
//});

//function onDrop(ev, ui, dropElem){
//	var elemPos = dropElem.attr('class').split(" ");
//	var elemPosClass = '.'+ elemPos[0];
//	var elemClass = ui.draggable.parent().attr('rel');
//	var elemsPos = [];
//	var elems = [];
//	$(elemPosClass).each(function(){
//		elemsPos.push($(this));
//	});
//	$('.'+elemClass).each(function(){
//		elems.push($(this).html());
//	});
//	if(elemPos[0] != elemClass){
//		$('.'+elemClass).remove();
//		ui.draggable.prev().attr('checked','true');
//		for(var i =0; i<elems.length; i++ ){
//			if(i==0){
//				var htmlContent = '<th class="'+elemClass+' ui-droppable">'+elems[i]+'</th>';
//				elemsPos[i].before(htmlContent);
//				elemsPos[i].prev().droppable({
//					drop: function(event, ui){
//						var dropElem = $(this);
//						onDrop(event, ui, dropElem);
//					},
//					accept: "#selectColumns li label"
//				});
//			}else{
//				var htmlContent = '<td class="'+elemClass+'">'+elems[i]+'</td>';
//				elemsPos[i].before(htmlContent);
//			}
//		}
//	}
//}

//function showChainData(x){		  
//		  if(x==1){
//		  	$('.chainTextBox, .chainCode').show();			
//			$('.chainCode').html('Enter 6 digit Code');
//		  }
//		  if(x==2){		  	
//			$('.chainTextBox, .chainCode').show();			
//			$('.chainCode').html('Enter first 3 digit Code');
//		  }
//		  if(x==0){
//		  		$('.chainTextBox, .chainCode').hide();
//		  }
//		  
//		  }
//		  function showChainData2(x){		  
//		  if(x==1){
//		  	$('.chainTextBox2, .chainCode2').show();			
//			$('.chainCode2').html('Enter 6 digit Code');
//		  }
//		  if(x==2){		  	
//			$('.chainTextBox2, .chainCode2').show();			
//			$('.chainCode2').html('Enter first 3 digit Code');
//		  }
//		  if(x==0){
//		  		$('.chainTextBox2, .chainCode2').hide();
//		  }
//		  
//		  }
//		  
//		  function showChainData3(x){		  
//		  if(x==1){
//		  	$('.chainTextBox3, .chainCode3').show();			
//			$('.chainCode3').html('Enter 6 digit Code');
//		  }
//		  if(x==2){		  	
//			$('.chainTextBox3, .chainCode3').show();			
//			$('.chainCode3').html('Enter first 3 digit Code');
//		  }
//		  if(x==0){
//		  		$('.chainTextBox3, .chainCode3').hide();
//		  }
//		  
//		  }		
//		  
//		   function EnableDisableDIV() {	
//		   if ($("#chkShowPersonal").attr("checked")) {				  			
//                  $("#dvPersonal").show();
//              } else {
//              $("#dvPersonal").hide()
//			  }
//          }
//		  
//		  function closetab() {	
//		   if ($("#chkShowPersonala").attr("checked")) {				  			
//                  $("#dvPersonala").show();
//              } else {
//              $("#dvPersonala").hide()
//			  }
//          }

//          $(document).ready(function () {
//              $(".toggle_container").hide();
//              $("h2.expand_heading").toggle(function () {
//                  $(this).addClass("active");
//              }, function () {
//                  $(this).removeClass("active");
//              });
//              $("h2.expand_heading").click(function () {
//                  $(this).next(".toggle_container").slideToggle("slow");
//              });
//              $(".expand_all").toggle(function () {
//                  $(this).addClass("expanded");
//              }, function () {
//                  $(this).removeClass("expanded");
//              });
//              $(".expand_all").click(function () {
//                  $(".toggle_container").slideToggle("slow");
//              });
//              //jQuery(".tablesorter")

//              /*
//              * td.collapsible = collapse to the first table row and show +/-
//              * td.collapsible_alt = anchor to order number
//              */
//             // jQuery(".tablesorter").collapsible("td.collapsible", {
//						    //collapse: true

//						//})

//		});

//		  function addRow(tableID) {
// 
//            var table = document.getElementById(tableID);
// 
//            var rowCount = table.rows.length;			
//            var row = table.insertRow(rowCount);			
// 
//            var cell0 = row.insertCell(0);
//            var element0 = document.createElement("select");
//			var option;
//			
//			option = document.createElement("option");
//			option.setAttribute("value", "APO Admin");
//			option.innerHTML = "APO Admin";
//			element0.appendChild(option);
//			
//			option = document.createElement("option");
//			option.setAttribute("value", "APO Super User");
//			option.innerHTML = "APO Super User";
//			element0.appendChild(option);
//			
//			option = document.createElement("option");
//			option.setAttribute("value", "APO User");
//			option.innerHTML = "APO User";
//			element0.appendChild(option);
//			
//			option = document.createElement("option");
//			option.setAttribute("value", "OpCO User");
//			option.innerHTML = "OpCO User";
//			element0.appendChild(option);
//			
//			option = document.createElement("option");
//			option.setAttribute("value", "APO IM");
//			option.innerHTML = "APO IM";
//			element0.appendChild(option);
//			
//			option = document.createElement("option");
//			option.setAttribute("value", "CSC User");
//			option.innerHTML = "CSC User";
//			element0.appendChild(option);
//						            
//            cell0.appendChild(element0);
// 
//            var cell1 = row.insertCell(1);
//            var element1 = document.createElement("input");
//            element1.type = "checkbox";
//            cell1.appendChild(element1);
// 
//            var cell2 = row.insertCell(2);
//            var element2 = document.createElement("input");
//            element2.type = "checkbox";
//            cell2.appendChild(element2);
//			
//			var cell3 = row.insertCell(3);
//            var element3 = document.createElement("input");
//            element3.type = "checkbox";
//            cell3.appendChild(element3);
//			
//			var cell4 = row.insertCell(4);
//            var element4 = document.createElement("input");
//            element4.type = "checkbox";
//            cell4.appendChild(element4);
//			
//			var cell5 = row.insertCell(5);
//            var element5 = document.createElement("input");
//            element5.type = "checkbox";
//            cell5.appendChild(element5);
//			
//			var cell6 = row.insertCell(6);
//            var element6 = document.createElement("input");
//            element6.type = "checkbox";
//            cell6.appendChild(element6);
//			
//			var cell7 = row.insertCell(7);
//            var element7 = document.createElement("input");
//            element7.type = "checkbox";
//            cell7.appendChild(element7);
//			
//			var cell8 = row.insertCell(8);
//            var element8 = document.createElement("input");
//            element8.type = "checkbox";
//            cell8.appendChild(element8);
//			
//			var cell9 = row.insertCell(9);
//            var element9 = document.createElement("input");
//            element9.type = "checkbox";
//            cell9.appendChild(element9);
//			
//			var cell10 = row.insertCell(10);
//            var element10 = document.createElement("input");
//            element10.type = "checkbox";
//            cell10.appendChild(element10);
//			
//			var cell11 = row.insertCell(11);
//            var element11 = document.createElement("input");
//            element11.type = "checkbox";
//            cell11.appendChild(element11);
//			
//			//var cell12 = row.insertCell(12);
//            //var element12 = document.createElement("input");
//            //element12.type = "checkbox";
//            //cell12.appendChild(element12);
//			
//			var cell12 = row.insertCell(12);
//            var element12 = document.createElement("img");
//            element12.src = "images/delete.png";
//			element12.className="UdeleteRow imgbin";
//			
//            cell12.appendChild(element12);
// 
//        }


