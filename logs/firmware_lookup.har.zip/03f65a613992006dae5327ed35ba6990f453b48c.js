
function CancelRequest() {
    if (Sys != null) {
        var prm = Sys.WebForms.PageRequestManager.getInstance();
        if (prm.get_isInAsyncPostBack()) {
            prm.abortPostBack();
        }
    }
}

function CloseError() {
    var oAsyncWaitDiv = document.getElementById("AsyncWaitCnt");
    var oAsyncWaitIframe = document.getElementById("AsyncWaitIframe");
    var oAsyncWaitTableError = document.getElementById("AsyncWaitTableError");

    if ((oAsyncWaitDiv != null) && (oAsyncWaitIframe != null)) {
        if (oAsyncWaitTableError != null) {
            oAsyncWaitTableError.style.display = "none";
        }

        oAsyncWaitDiv.style.display = "none";
        oAsyncWaitIframe.style.display = "none";
    }
}

function EndRequestHandler(sender, args) {
    // scroll(0, 0);
    var oAsyncWaitDiv = document.getElementById("AsyncWaitCnt");
    var oAsyncWaitIframe = document.getElementById("AsyncWaitIframe");
    var oAsyncWaitTableUpdate = document.getElementById("AsyncWaitTableUpdate");
    var oAsyncWaitTableError = document.getElementById("AsyncWaitTableError");
    var oAsyncWaitErrorMessage = document.getElementById("AsyncWaitErrorMessage");

    if ((oAsyncWaitDiv != null) && (oAsyncWaitIframe != null)) {
        // hide the wait message panel
        if (oAsyncWaitTableUpdate != null) {
            oAsyncWaitTableUpdate.style.display = "none";
        }

        // Check to see if there's an error on this request.
        if (args.get_error() != undefined) {
            // Let the framework know that the error is handled
            args.set_errorHandled(true);

            // attempt to grab relevant error message
            //var ErrorMessage = "Please check your network connection, A network-related or instance-specific error occurred while establishing connection ";
            var ErrorMessage = "Please check your network connection " + args.get_error() + " Status Code: " + args.get_response().get_statusCode();
            //"No error detail could be retrieved";

            if (args.get_response().get_statusCode() == '200') {
                ErrorMessage = args.get_error().message.replace("Sys.WebForms.PageRequestManagerServerErrorException: ", "");
            }

            if (args.get_response().get_statusCode() == '0') {
                // hide the background iframe...
                oAsyncWaitIframe.style.display = "none";
                oAsyncWaitDiv.style.display = "none";
            }

            // show the error message panel
            var DisplayViaAlert = false;

            if (oAsyncWaitTableError != null) {
                if (oAsyncWaitErrorMessage != null) {
                    // display the error in div panel
                    oAsyncWaitErrorMessage.innerHTML = ErrorMessage;
                    oAsyncWaitTableError.style.display = "block";
                }
                else {
                    DisplayViaAlert = true;
                }
            }
            else {
                DisplayViaAlert = true;
            }

            if (DisplayViaAlert) {
                // display the error in alert box
                alert(ErrorMessage);
            }
        }
        else {
            // hide the background iframe...
            oAsyncWaitIframe.style.display = "none";
        }

       
    }

    // resize controls if defined...
    if (window.SetInputFieldWidths) {
        SetInputFieldWidths();
    }

    

    ScrollUp();
}

function BeginRequestHandler(sender, args) {
    var oAsyncWaitDiv = document.getElementById("AsyncWaitCnt");
    var oAsyncWaitIframe = document.getElementById("AsyncWaitIframe");
    var oAsyncWaitTableUpdate = document.getElementById("AsyncWaitTableUpdate");
    var oAsyncWaitTableError = document.getElementById("AsyncWaitTableError");

    if ((oAsyncWaitDiv != null) && (oAsyncWaitIframe != null)) {
        var WindowWidth = GetWindowWidth();
        var WindowHeight = GetWindowHeight();
        var DocumentHeight = GetDocumentHeight();

        // set the iframe full page...
        setControlWidth(oAsyncWaitIframe.id, WindowWidth);
        setControlHeight(oAsyncWaitIframe.id, DocumentHeight);

        // show the background iframe...
        oAsyncWaitIframe.style.display = "block";

        // center the div
        oAsyncWaitDiv.style.left = (WindowWidth / 2) - 200 + "px";
        oAsyncWaitDiv.style.top = (WindowHeight / 2) - 95 + "px";
        oAsyncWaitDiv.style.display = "block";

        // hide the error message panel
        if (oAsyncWaitTableError != null) {
            oAsyncWaitTableError.style.display = "none";
        }

        // show the wait message panel
        if (oAsyncWaitTableUpdate != null) {
            oAsyncWaitTableUpdate.style.display = "block";
        }
    }

    var hdnTimeOut = $("input[id*='hdnTimeout']").val();
    SessionTimeOut(hdnTimeOut);
}

function AppLoad() {
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(EndRequestHandler);
    Sys.WebForms.PageRequestManager.getInstance().add_beginRequest(BeginRequestHandler);
}

function GetDocumentHeight() {
    var D = document;
    return Math.max(Math.max(D.body.scrollHeight, D.documentElement.scrollHeight), Math.max(D.body.offsetHeight, D.documentElement.offsetHeight), Math.max(D.body.clientHeight, D.documentElement.clientHeight));
}

function setControlWidth(ControlClientId, WidthPixels) {
    if (ControlClientId != "") {
        var oControl = document.getElementById(ControlClientId);
        if (oControl != null) {
            try {
                WidthPixels = parseInt(WidthPixels);
                if (oControl.nodeName.toLowerCase()
                    == "iframe") {
                    oControl.style.width = WidthPixels + "px";
                } else {
                    if (oControl.style) {
                        oControl.style.width = WidthPixels + "px";
                    } else {
                        if (oControl.width)
                            oControl.width = WidthPixels;
                    }
                }
            } catch (Exc) {
                alert("Failed while setting control width: " + ControlClientId + " - " + WidthPixels + ": " + Exc.description);

            }
        } else {
            alert("Could not locate control: " + ControlClientId);

        }
    }
}

function setControlHeight(ControlClientId, HeightPixels) {
    if (ControlClientId != "") {
        var oControl = document.getElementById(ControlClientId);
        if (oControl != null) {
            try {
                HeightPixels = parseInt(HeightPixels);
                if (oControl.nodeName.toLowerCase()
                    == "iframe") {
                    oControl.style.height = HeightPixels + "px";
                } else {
                    if (oControl.style) {
                        oControl.style.height = HeightPixels + "px";
                    } else {
                        if (oControl.height)
                            oControl.height = HeightPixels;
                    }
                }
            } catch (Exc) {
                alert("Failed while setting control height: " + ControlClientId + " - " + HeightPixels + ": " + Exc.description);

            }
        } else {
            alert("Could not locate control: " + ControlClientId);
        }
    }
}

